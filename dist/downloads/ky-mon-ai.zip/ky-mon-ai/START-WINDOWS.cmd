@echo off
cd /d "%~dp0"
node local/server.mjs
pause
