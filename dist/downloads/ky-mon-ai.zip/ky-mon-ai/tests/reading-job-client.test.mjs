import test from 'node:test';
import assert from 'node:assert/strict';
import {createReadingJobClient} from '../dist/reading-job-client.mjs';

const response=(data,status=200)=>new Response(JSON.stringify(data),{status,headers:{'Content-Type':'application/json'}});

test('job client survives a temporary mobile network loss and later returns the completed result',async t=>{
  const original={fetch:globalThis.fetch,document:globalThis.document};
  t.after(()=>{globalThis.fetch=original.fetch;globalThis.document=original.document;});
  globalThis.document={hidden:false};
  let starts=0,polls=0,reconnects=0,running=0;
  globalThis.fetch=async url=>{
    if(url.endsWith('/api/read/start')){starts++;if(starts===1)throw new TypeError('response lost while app backgrounds');return response({jobId:'abcdefghijklmnopqrstuvwx',status:'running',reused:true},202);}
    if(url.includes('/api/jobs/')){
      polls++;
      if(polls===1)throw new TypeError('network lost');
      if(polls===2)return response({jobId:'abcdefghijklmnopqrstuvwx',status:'running'});
      return response({jobId:'abcdefghijklmnopqrstuvwx',status:'completed',result:{reading:{status:'completed'},ok:true}});
    }
    throw new Error('unexpected '+url);
  };
  const client=createReadingJobClient({endpoint:'https://relay.example',getToken:()=> 'token',pollMs:1,hiddenPollMs:1,onReconnect(){reconnects++;},onRunning(){running++;}});
  const started=await client.start('/api/read/start',{request:'x'});
  assert.equal(started.jobId,'abcdefghijklmnopqrstuvwx');
  const result=await client.wait(started.jobId,new AbortController().signal);
  assert.deepEqual(result,{reading:{status:'completed'},ok:true});
  assert.equal(starts,2);assert.equal(reconnects,2);assert.equal(running,1);assert.equal(polls,3);
});

test('job client cancel uses the explicit DELETE job endpoint',async t=>{
  const original=globalThis.fetch;t.after(()=>{globalThis.fetch=original;});
  let method,path;
  globalThis.fetch=async(url,options)=>{path=url;method=options.method;return response({status:'cancelling'},202);};
  const client=createReadingJobClient({endpoint:'https://relay.example',getToken:()=> 'token',pollMs:1});
  await client.cancel('abcdefghijklmnopqrstuvwx');
  assert.equal(method,'DELETE');assert.match(path,/\/api\/jobs\/abcdefghijklmnopqrstuvwx$/);
});

test('job client recreates one lost server job after a restart and returns the replacement result',async t=>{
  const original={fetch:globalThis.fetch,document:globalThis.document};
  t.after(()=>{globalThis.fetch=original.fetch;globalThis.document=original.document;});
  globalThis.document={hidden:false};
  let starts=0,polls=0,recovered=0;const jobs=[];
  globalThis.fetch=async url=>{
    if(url.endsWith('/api/read/start')){
      starts++;
      return response({jobId:starts===1?'abcdefghijklmnopqrstuvwx':'zyxwvutsrqponmlkjihgfedc',status:'running',reused:false},202);
    }
    if(url.includes('/api/jobs/')){
      polls++;
      if(url.endsWith('abcdefghijklmnopqrstuvwx'))return response({error:'Lượt luận không tồn tại hoặc đã hết thời gian lưu.'},404);
      return response({jobId:'zyxwvutsrqponmlkjihgfedc',status:'completed',result:{reading:{status:'completed'},recovered:true}});
    }
    throw new Error('unexpected '+url);
  };
  const client=createReadingJobClient({endpoint:'https://relay.example',getToken:()=> 'token',pollMs:1,hiddenPollMs:1});
  const result=await client.run('/api/read/start',{request:'same'},new AbortController().signal,{
    onJob(id){jobs.push(id);},onRecovered(){recovered++;}
  });
  assert.deepEqual(result,{reading:{status:'completed'},recovered:true});
  assert.equal(starts,2);assert.equal(recovered,1);assert.deepEqual(jobs,['abcdefghijklmnopqrstuvwx','zyxwvutsrqponmlkjihgfedc']);assert.equal(polls,2);
});
